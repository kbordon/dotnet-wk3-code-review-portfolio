-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 26, 2018 at 09:47 AM
-- Server version: 5.6.35
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio`
--
CREATE DATABASE IF NOT EXISTS `portfolio` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `portfolio`;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetRoleClaims`
--

CREATE TABLE `AspNetRoleClaims` (
  `Id` int(11) NOT NULL,
  `ClaimType` longtext,
  `ClaimValue` longtext,
  `RoleId` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetRoles`
--

CREATE TABLE `AspNetRoles` (
  `Id` varchar(127) NOT NULL,
  `ConcurrencyStamp` longtext,
  `Name` varchar(127) DEFAULT NULL,
  `NormalizedName` varchar(127) DEFAULT NULL,
  `Discriminator` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `AspNetRoles`
--

INSERT INTO `AspNetRoles` (`Id`, `ConcurrencyStamp`, `Name`, `NormalizedName`, `Discriminator`) VALUES
('1f88dc7a-0723-4424-ae94-0afc9a1cf3f4', 'df9d83b5-a331-4915-88e1-630e6738edc1', 'ADMIN', 'ADMIN', 'BlogRole'),
('d57aee10-3d22-4fe1-9c8a-38df079b78ae', '088c3dc3-755f-421f-b086-b8ef2c5420f2', 'USER', 'USER', 'BlogRole');

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserClaims`
--

CREATE TABLE `AspNetUserClaims` (
  `Id` int(11) NOT NULL,
  `ClaimType` longtext,
  `ClaimValue` longtext,
  `UserId` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserLogins`
--

CREATE TABLE `AspNetUserLogins` (
  `LoginProvider` varchar(127) NOT NULL,
  `ProviderKey` varchar(127) NOT NULL,
  `ProviderDisplayName` longtext,
  `UserId` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserRoles`
--

CREATE TABLE `AspNetUserRoles` (
  `UserId` varchar(127) NOT NULL,
  `RoleId` varchar(127) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `AspNetUserRoles`
--

INSERT INTO `AspNetUserRoles` (`UserId`, `RoleId`) VALUES
('7480628e-935d-473a-9fd9-3e7021c9d2d8', '1f88dc7a-0723-4424-ae94-0afc9a1cf3f4'),
('6ecb09e5-b815-476d-af58-6b896c057a3b', 'd57aee10-3d22-4fe1-9c8a-38df079b78ae'),
('df66bc1a-d5bc-48f1-aeab-56b3d2053916', 'd57aee10-3d22-4fe1-9c8a-38df079b78ae');

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUsers`
--

CREATE TABLE `AspNetUsers` (
  `Id` varchar(127) NOT NULL,
  `AccessFailedCount` int(11) NOT NULL,
  `ConcurrencyStamp` longtext,
  `Email` varchar(127) DEFAULT NULL,
  `EmailConfirmed` bit(1) NOT NULL,
  `LockoutEnabled` bit(1) NOT NULL,
  `LockoutEnd` datetime(6) DEFAULT NULL,
  `NormalizedEmail` varchar(127) DEFAULT NULL,
  `NormalizedUserName` varchar(127) DEFAULT NULL,
  `PasswordHash` longtext,
  `PhoneNumber` longtext,
  `PhoneNumberConfirmed` bit(1) NOT NULL,
  `SecurityStamp` longtext,
  `TwoFactorEnabled` bit(1) NOT NULL,
  `UserName` varchar(127) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `AspNetUsers`
--

INSERT INTO `AspNetUsers` (`Id`, `AccessFailedCount`, `ConcurrencyStamp`, `Email`, `EmailConfirmed`, `LockoutEnabled`, `LockoutEnd`, `NormalizedEmail`, `NormalizedUserName`, `PasswordHash`, `PhoneNumber`, `PhoneNumberConfirmed`, `SecurityStamp`, `TwoFactorEnabled`, `UserName`) VALUES
('6ecb09e5-b815-476d-af58-6b896c057a3b', 0, 'deda3866-8a16-4dc3-8be0-ee740525b530', NULL, b'0', b'1', NULL, NULL, 'USER', 'AQAAAAEAACcQAAAAEH8e117w6WO/w4GhbyyG6NUUFxkmSylx9y+wqxHd9YZdZXhIXtoobW67cw2+Wu/VMA==', NULL, b'0', 'd0182924-ea3a-46ae-a5f1-5c747f9dc9d3', b'0', 'User'),
('7480628e-935d-473a-9fd9-3e7021c9d2d8', 0, '0259aec7-5093-4b9c-8c60-c22277ed922e', NULL, b'0', b'1', NULL, NULL, 'ADMIN', 'AQAAAAEAACcQAAAAEGbeNJsy/szFLBOfy1qKFXDmH3P0ObsidshSRQyGolDlRuQocKu8z5v56mhJBJD9rg==', NULL, b'0', 'b81e2068-54d2-4a81-8a18-09048a4c91b5', b'0', 'Admin'),
('df66bc1a-d5bc-48f1-aeab-56b3d2053916', 0, 'f9563468-69bb-4de1-9466-4548488b4335', NULL, b'0', b'1', NULL, NULL, 'KMBY', 'AQAAAAEAACcQAAAAEM2nuHv5zo2AyznLyttMzLDQ54p+RgApuqvkkKmojLUX2MY8Se6KDFYY4DVqeK+nVQ==', NULL, b'0', 'e8c5b421-f071-4661-8ea9-078c3b919e6c', b'0', 'kmby');

-- --------------------------------------------------------

--
-- Table structure for table `AspNetUserTokens`
--

CREATE TABLE `AspNetUserTokens` (
  `UserId` varchar(127) NOT NULL,
  `LoginProvider` varchar(127) NOT NULL,
  `Name` varchar(127) NOT NULL,
  `Value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `CommentId` int(11) NOT NULL,
  `Author` longtext,
  `Content` longtext,
  `Date` datetime(6) NOT NULL,
  `PostId` int(11) NOT NULL,
  `UserId` varchar(127) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`CommentId`, `Author`, `Content`, `Date`, `PostId`, `UserId`) VALUES
(10, NULL, 'I am a user.', '2018-01-25 09:28:14.159972', 3, '6ecb09e5-b815-476d-af58-6b896c057a3b'),
(11, 'User', 'Here\'s a comment from User.', '2018-01-25 09:30:20.948945', 3, '6ecb09e5-b815-476d-af58-6b896c057a3b'),
(12, 'Admin', 'here is a comment', '2018-01-25 14:43:21.786444', 3, '7480628e-935d-473a-9fd9-3e7021c9d2d8'),
(13, 'Admin', 'another comment', '2018-01-25 15:04:02.350219', 3, '7480628e-935d-473a-9fd9-3e7021c9d2d8'),
(19, NULL, 'hii', '2018-01-25 22:06:07.360212', 6, '7480628e-935d-473a-9fd9-3e7021c9d2d8'),
(20, 'Super Duper', 'heeeyyy', '2018-01-25 22:37:09.328925', 6, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `PostId` int(11) NOT NULL,
  `Content` longtext,
  `Date` datetime(6) NOT NULL,
  `Title` longtext,
  `UserId` varchar(127) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`PostId`, `Content`, `Date`, `Title`, `UserId`) VALUES
(3, 'well actually it is, but you don\'t need to know that shit.', '2018-01-24 21:23:22.050000', 'this is a test actually', '7480628e-935d-473a-9fd9-3e7021c9d2d8'),
(5, 'Hey, what kinda party is this? There\'s no booze and only one hooker.\r\nHello, little man. I will destroy you! I decline the title of Iron Cook and accept the lesser title of Zinc Saucier, which I just made up. Uhh… also, comes with double prize money. Say it in Russian!\r\n\r\nYes, I saw. You were doing well, until everyone died. We\'ll go deliver this crate like professionals, and then we\'ll go home. Dear God, they\'ll be killed on our doorstep! And there\'s no trash pickup until January 3rd.\r\n\r\nFatal.\r\nAre you crazy? I can\'t swallow that. Ah, the \'Breakfast Club\' soundtrack! I can\'t wait til I\'m old enough to feel ways about stuff! Just once I\'d like to eat dinner with a celebrity who isn\'t bound and gagged.\r\n\r\nBender! Ship! Stop bickering or I\'m going to come back there and change your opinions manually!\r\nYou mean while I\'m sleeping in it?\r\nYou guys aren\'t Santa! You\'re not even robots. How dare you lie in front of Jesus?\r\nOK, if everyone\'s finished being stupid.\r\nYeah. Give a little credit to our public schools. We\'ll go deliver this crate like professionals, and then we\'ll go home. Is that a cooking show? Oh, I always feared he might run off like this. Why, why, why didn\'t I break his legs?\r\n\r\nHey, guess what you\'re accessories to.\r\nThen we\'ll go with that data file!\r\nYou, minion. Lift my arm. AFTER HIM!\r\nOh Leela! You\'re the only person I could turn to; you\'re the only person who ever loved me. I don\'t know what you did, Fry, but once again, you screwed up! Now all the planets are gonna start cracking wise about our mamas.\r\n\r\nYou guys aren\'t Santa! You\'re not even robots. How dare you lie in front of Jesus? I could if you hadn\'t turned on the light and shut off my stereo. This is the worst part. The calm before the battle. I\'m sorry, guys. I never meant to hurt you. Just to destroy everything you ever believed in.\r\n\r\nI decline the title of Iron Cook and accept the lesser title of Zinc Saucier, which I just made up. Uhh… also, comes with double prize money. I videotape every customer that comes in here, so that I may blackmail them later.', '2017-01-25 08:08:19.819000', 'fillerama', '7480628e-935d-473a-9fd9-3e7021c9d2d8'),
(6, 'well okay it makes sense that it will only go to blog index.', '2018-01-25 20:17:43.473000', 'what happens on this', '7480628e-935d-473a-9fd9-3e7021c9d2d8');

-- --------------------------------------------------------

--
-- Table structure for table `__EFMigrationsHistory`
--

CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` varchar(95) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `__EFMigrationsHistory`
--

INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`) VALUES
('20180119180101_Initial', '1.1.2'),
('20180119194740_AddPostTable', '1.1.2'),
('20180119213618_FixUserTable', '1.1.2'),
('20180121061756_AddCommentTable', '1.1.2'),
('20180121083150_RemovePostId', '1.1.2'),
('20180121101121_ReturnPostId', '1.1.2'),
('20180121104337_ChangeColumns', '1.1.2'),
('20180123220452_AddBlogRoles', '1.1.2'),
('20180124071730_AddUserIdToComments', '1.1.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AspNetRoleClaims`
--
ALTER TABLE `AspNetRoleClaims`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_AspNetRoleClaims_RoleId` (`RoleId`);

--
-- Indexes for table `AspNetRoles`
--
ALTER TABLE `AspNetRoles`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `RoleNameIndex` (`NormalizedName`);

--
-- Indexes for table `AspNetUserClaims`
--
ALTER TABLE `AspNetUserClaims`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_AspNetUserClaims_UserId` (`UserId`);

--
-- Indexes for table `AspNetUserLogins`
--
ALTER TABLE `AspNetUserLogins`
  ADD PRIMARY KEY (`LoginProvider`,`ProviderKey`),
  ADD KEY `IX_AspNetUserLogins_UserId` (`UserId`);

--
-- Indexes for table `AspNetUserRoles`
--
ALTER TABLE `AspNetUserRoles`
  ADD PRIMARY KEY (`UserId`,`RoleId`),
  ADD KEY `IX_AspNetUserRoles_RoleId` (`RoleId`);

--
-- Indexes for table `AspNetUsers`
--
ALTER TABLE `AspNetUsers`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `UserNameIndex` (`NormalizedUserName`),
  ADD KEY `EmailIndex` (`NormalizedEmail`);

--
-- Indexes for table `AspNetUserTokens`
--
ALTER TABLE `AspNetUserTokens`
  ADD PRIMARY KEY (`UserId`,`LoginProvider`,`Name`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`CommentId`),
  ADD KEY `IX_comments_PostId` (`PostId`),
  ADD KEY `IX_comments_UserId` (`UserId`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`PostId`),
  ADD KEY `IX_posts_UserId` (`UserId`);

--
-- Indexes for table `__EFMigrationsHistory`
--
ALTER TABLE `__EFMigrationsHistory`
  ADD PRIMARY KEY (`MigrationId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AspNetRoleClaims`
--
ALTER TABLE `AspNetRoleClaims`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `AspNetUserClaims`
--
ALTER TABLE `AspNetUserClaims`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `CommentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `PostId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `AspNetRoleClaims`
--
ALTER TABLE `AspNetRoleClaims`
  ADD CONSTRAINT `FK_AspNetRoleClaims_AspNetRoles_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `AspNetRoles` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserClaims`
--
ALTER TABLE `AspNetUserClaims`
  ADD CONSTRAINT `FK_AspNetUserClaims_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserLogins`
--
ALTER TABLE `AspNetUserLogins`
  ADD CONSTRAINT `FK_AspNetUserLogins_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `AspNetUserRoles`
--
ALTER TABLE `AspNetUserRoles`
  ADD CONSTRAINT `FK_AspNetUserRoles_AspNetRoles_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `AspNetRoles` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_AspNetUserRoles_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `FK_comments_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_comments_posts_PostId` FOREIGN KEY (`PostId`) REFERENCES `posts` (`PostId`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `FK_posts_AspNetUsers_UserId` FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
